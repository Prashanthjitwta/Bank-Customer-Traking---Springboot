package com.example.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="accrequest")
public class RequestCustomer {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int Id;
	
	@Column(name = "custName")
	private String custName;
	@Column(name = "custAge")
	private String custAge;
	@Column(name = "custPhone")
	private String custPhone;
	@Column(name = "custEmail")
	private String custEmail;
	@Column(name = "custAadhar")
	private String custAadhar;
	@Column(name = "custAccOwership")
	private String custAccOwership;
	@Column(name = "custAccType")
	private String custAccType;
	
public RequestCustomer() {
		
	}

public RequestCustomer(int id, String custName, String custAge, String custPhone, String custEmail, String custAadhar,
		String custAccOwership, String custAccType) {
	super();
	Id = id;
	this.custName = custName;
	this.custAge = custAge;
	this.custPhone = custPhone;
	this.custEmail = custEmail;
	this.custAadhar = custAadhar;
	this.custAccOwership = custAccOwership;
	this.custAccType = custAccType;
}

public int getId() {
	return Id;
}

public void setId(int id) {
	Id = id;
}

public String getCustName() {
	return custName;
}

public void setCustName(String custName) {
	this.custName = custName;
}

public String getCustAge() {
	return custAge;
}

public void setCustAge(String custAge) {
	this.custAge = custAge;
}

public String getCustPhone() {
	return custPhone;
}

public void setCustPhone(String custPhone) {
	this.custPhone = custPhone;
}

public String getCustEmail() {
	return custEmail;
}

public void setCustEmail(String custEmail) {
	this.custEmail = custEmail;
}

public String getCustAadhar() {
	return custAadhar;
}

public void setCustAadhar(String custAadhar) {
	this.custAadhar = custAadhar;
}

public String getCustAccOwership() {
	return custAccOwership;
}

public void setCustAccOwership(String custAccOwership) {
	this.custAccOwership = custAccOwership;
}

public String getCustAccType() {
	return custAccType;
}

public void setCustAccType(String custAccType) {
	this.custAccType = custAccType;
}

}

	