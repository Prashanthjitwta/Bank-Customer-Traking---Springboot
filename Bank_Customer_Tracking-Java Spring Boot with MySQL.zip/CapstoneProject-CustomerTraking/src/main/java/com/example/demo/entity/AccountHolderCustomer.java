package com.example.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="AccountHolderDetails")
public class AccountHolderCustomer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name = "custName")
	private String custName;
	@Column(name = "custEmail")
	private String custEmail;
	@Column(name = "custAccNo")
	private String custAccNo;
	@Column(name = "custAadhar")
	private String custAadhar;             
	@Column(name = "custOwnership")
	private String custOwnership;
	@Column(name = "custAccType")
	private String custAccType;
	@Column(name = "custPhone")
	private String custPhone;
	
	public AccountHolderCustomer() {
	
	}

	public AccountHolderCustomer(int id, String custName, String custEmail, String custAccNo, String custAadhar,
			String custOwnership, String custAccType, String custPhone) {
		super();
		this.id = id;
		this.custName = custName;
		this.custEmail = custEmail;
		this.custAccNo = custAccNo;
		this.custAadhar = custAadhar;
		this.custOwnership = custOwnership;
		this.custAccType = custAccType;
		this.custPhone = custPhone;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getCustEmail() {
		return custEmail;
	}

	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}

	public String getCustAccNo() {
		return custAccNo;
	}

	public void setCustAccNo(String custAccNo) {
		this.custAccNo = custAccNo;
	}

	public String getCustAadhar() {
		return custAadhar;
	}

	public void setCustAadhar(String custAadhar) {
		this.custAadhar = custAadhar;
	}

	public String getCustOwnership() {
		return custOwnership;
	}

	public void setCustOwnership(String custOwnership) {
		this.custOwnership = custOwnership;
	}

	public String getCustAccType() {
		return custAccType;
	}

	public void setCustAccType(String custAccType) {
		this.custAccType = custAccType;
	}

	public String getCustPhone() {
		return custPhone;
	}

	public void setCustPhone(String custPhone) {
		this.custPhone = custPhone;
	}

	
}
