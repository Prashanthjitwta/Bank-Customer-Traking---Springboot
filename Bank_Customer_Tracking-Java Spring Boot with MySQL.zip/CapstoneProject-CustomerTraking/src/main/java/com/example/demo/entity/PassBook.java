package com.example.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="PassBook")
public class PassBook {		
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private int Id;
		
		@Column(name = "balanceAmt")
		private String balanceAmt;
		@Column(name = "credit")
		private String credit;
		@Column(name = "debit")
		private String debit;
		@Column(name = "time")
		private String time;
		@Column(name = "accno")
		private String accNo;
		public PassBook() {
			
		}
		public PassBook(int id, String balanceAmt, String credit, String debit, String time, String accNo) {
			super();
			Id = id;
			this.balanceAmt = balanceAmt;
			this.credit = credit;
			this.debit = debit;
			this.time = time;
			this.accNo = accNo;
		}
		public int getId() {
			return Id;
		}
		public void setId(int id) {
			Id = id;
		}
		public String getBalanceAmt() {
			return balanceAmt;
		}
		public void setBalanceAmt(String balanceAmt) {
			this.balanceAmt = balanceAmt;
		}
		public String getCredit() {
			return credit;
		}
		public void setCredit(String credit) {
			this.credit = credit;
		}
		public String getDebit() {
			return debit;
		}
		public void setDebit(String debit) {
			this.debit = debit;
		}
		public String getTime() {
			return time;
		}
		public void setTime(String time) {
			this.time = time;
		}
		public String getAccNo() {
			return accNo;
		}
		public void setAccNo(String accNo) {
			this.accNo = accNo;
		}
		
}
