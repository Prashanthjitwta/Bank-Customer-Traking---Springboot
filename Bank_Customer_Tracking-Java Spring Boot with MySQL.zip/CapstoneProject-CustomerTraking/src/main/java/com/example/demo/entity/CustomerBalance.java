package com.example.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="BankBalance")
public class CustomerBalance {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int Id;
	
	@Column(name = "accNumber")
	private String accNumber;
	@Column(name = "accBalance")
	private String accBalance;
	
	public CustomerBalance() {

	}

	public CustomerBalance(int id, String accNumber, String accBalance) {
		super();
		Id = id;
		this.accNumber = accNumber;
		this.accBalance = accBalance;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getAccNumber() {
		return accNumber;
	}

	public void setAccNumber(String accNumber) {
		this.accNumber = accNumber;
	}

	public String getAccBalance() {
		return accBalance;
	}

	public void setAccBalance(String accBalance) {
		this.accBalance = accBalance;
	}
	
	

}
