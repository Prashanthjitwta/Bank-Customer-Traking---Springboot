package com.example.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="BankAccess")
public class BankLogin {		
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private int Id;
		
		@Column(name = "bankEmail")
		private String bankEmail;
		@Column(name = "bankPass")
		private String bankPass;
		
	public BankLogin() {
			
		}

	public BankLogin(int id, String bankEmail, String bankPass) {
		super();
		Id = id;
		this.bankEmail = bankEmail;
		this.bankPass = bankPass;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}


	public String getBankEmail() {
		return bankEmail;
	}

	public void setBankEmail(String bankEmail) {
		this.bankEmail = bankEmail;
	}

	public String getBankPass() {
		return bankPass;
	}

	public void setBankPass(String bankPass) {
		this.bankPass = bankPass;
	}
		
}
