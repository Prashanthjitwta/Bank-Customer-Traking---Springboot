package com.example.demo.service;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.Column;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.entity.*;
import com.example.demo.repository.*;

@Service
public class CustomerService {
	
	@Autowired
	private BankLoginRepository bankRepo; 
	
	@Autowired
	private CustomerLoginRepository custRepo;
	
	@Autowired
	private AccountHoldersRepository accholderRepo;
	
	@Autowired
	private CustomerBalanceRepository accbalanceRepo;
	
	@Autowired
	private AccRequestRepository accrequestRepo;
	
	@Autowired
	private PassBookRepository passbookRepo;
	
	
	public int logValidation(int role, String logMail, String logPass) {
		if(role == 1) {
		 List<BankLogin> list = bankRepo.findByBankEmailAndBankPass(logMail, logPass);
		 if(list.size()>0) {
		 String email = list.get(0).getBankEmail();
		 String pass = list.get(0).getBankPass();
		 	if(email.equals(logMail) && pass.equals(logPass)) {
		 		return 1;
		 	}
		 }
		 else {
			 System.out.println("No Record");
			 return 0;
		 }
		}
		
		if(role == 2) {
			 List<CustomerLogin> list = custRepo.findByCustomerEmailAndCustomerPass(logMail, logPass);
			 if(list.size()>0) {
			 String email = list.get(0).getCustomerEmail();
			 String pass = list.get(0).getCustomerPass();
			 	if(email.equals(logMail) && pass.equals(logPass)) {
			 		return 1;
			 	}
			 }
			 else {
				 System.out.println("No Record");
				 return 0;
			 }
			}
		 return 0;
		
	}

	public List<AccountHolderCustomer> getAllCustomers() {
		return accholderRepo.findAll();
	}

	public List<AccountHolderCustomer> getCustomerById(String accno) {
		return accholderRepo.findByCustAccNo(accno);
	}

	public List<CustomerBalance> checkCustomerBalance(String accNumber) { 
		return accbalanceRepo.findBalanceByAccNumber(accNumber);
	}

	public List<RequestCustomer> showAllNewRequest() {
		return accrequestRepo.findAll();
	}

	public int saveNewRequest(RequestCustomer newcustomer, String aadharno, String acctype) {
		int stat = 10;
		
		List<AccountHolderCustomer> exists = accholderRepo.findByCustAadharAndCustAccType(aadharno,acctype);
		
		List<RequestCustomer> exists1 = accrequestRepo.findByCustAadharAndCustAccType(aadharno,acctype);
		System.out.println(exists.size()); 
	
		if(exists.size() == 1 || exists1.size() == 1) {
			stat = 0;
		}
		if(exists.size() == 0 && exists1.size() == 0) {
			stat = 1;
		}
		if(stat == 1) {
			accrequestRepo.save(newcustomer);
			return 1;
		}
		if(stat == 0) {
			return 0;
		}
		
		return 0;
	}

	public void provideAccess(int id) {
		
		Optional<RequestCustomer> requestAccess = accrequestRepo.findById(id);
		String aadhar = requestAccess.get().getCustAadhar();
		String phone = requestAccess.get().getCustPhone();
		String name = requestAccess.get().getCustName();
		String accno = randomNumberGeneration();
		String email = requestAccess.get().getCustEmail();
		String acctype = requestAccess.get().getCustAccType();
		String accownership = requestAccess.get().getCustAccOwership();
		
		AccountHolderCustomer p = new AccountHolderCustomer();
		CustomerBalance r = new CustomerBalance();
		CustomerLogin s = new CustomerLogin();
		p.setCustAadhar(aadhar);
		p.setCustAccNo(accno);
		p.setCustAccType(acctype);
		p.setCustEmail(email);
		p.setCustName(name);
		p.setCustOwnership(accownership);
		p.setCustPhone(phone);
		accholderRepo.save(p);
		accrequestRepo.deleteById(id);
		r.setAccNumber(accno);
		r.setAccBalance("0");
		accbalanceRepo.save(r);
		s.setCustomerEmail(email);
		s.setCustomerPass("123");
		custRepo.save(s);
		
	}

	private String randomNumberGeneration() {
		int min = 200;  
		int max = 4000000;  
		int num = (int)(Math.random()*(max-min+1)+min); 
		int accno = (int) ((min+max+num)*2.45643);
		String accnum = String.valueOf(accno);  
		return accnum;
	}

	public void denyAccess(int id) {
		accrequestRepo.deleteById(id);
	}

	public List<AccountHolderCustomer> editCustomerDetails(String custlogMail) {
		return accholderRepo.findByCustEmail(custlogMail);
	}

	public AccountHolderCustomer saveEditRequest(String email, String phone, String pass, int id) {
		Optional<AccountHolderCustomer> existing = accholderRepo.findById(id);
		Optional<CustomerLogin> existingid = custRepo.findById(id);
		AccountHolderCustomer p = new AccountHolderCustomer();
		CustomerLogin s = new CustomerLogin();
		p.setId(existing.get().getId());
		p.setCustAadhar(existing.get().getCustAadhar());
		p.setCustAccNo(existing.get().getCustAccNo());
		p.setCustAccType(existing.get().getCustAccType());
		p.setCustName(existing.get().getCustName());
		p.setCustOwnership(existing.get().getCustOwnership());
		p.setCustEmail(email);
		p.setCustPhone(phone);
		s.setId(existingid.get().getId());
		s.setCustomerEmail(email);
		s.setCustomerPass(pass);
		custRepo.save(s);
		return accholderRepo.save(p);
		
	}

	public CustomerBalance addAmt(String amt, int id, String accno) {
		CustomerBalance p = new CustomerBalance();
		Optional<CustomerBalance> existingamt = accbalanceRepo.findById(id);
		String existbalance = existingamt.get().getAccBalance();
		Double balanceamt = Double.parseDouble(existbalance);
		Double added = Double.parseDouble(amt);
		Double totBalance = balanceamt+added;
		String totamt = String.valueOf(totBalance);
		p.setAccBalance(totamt);
		p.setAccNumber(accno);
		p.setId(id);
		PassBook pass = new PassBook();
		pass.setBalanceAmt(totamt);
		String add = String.valueOf(added);
		pass.setCredit(add);
		pass.setDebit("0");
		LocalDateTime myDateObj = LocalDateTime.now();
	    DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
	    String formattedDate = myDateObj.format(myFormatObj);
		pass.setTime(formattedDate);
		pass.setAccNo(accno);
		passbookRepo.save(pass);
		return accbalanceRepo.save(p);
		
	}

	public int addAmt(String amt, int id, String accno, String toacc) {
		int stat = 10;
		CustomerBalance p = new CustomerBalance();
		Optional<CustomerBalance> existingamt = accbalanceRepo.findById(id);
		String existbalance = existingamt.get().getAccBalance();
		Double balanceamt = Double.parseDouble(existbalance);
		Double transferringamt = Double.parseDouble(amt);
		if(transferringamt <= balanceamt) {
			stat = 0;
			List<CustomerBalance> acccheck = accbalanceRepo.findBalanceByAccNumber(toacc);
			if(acccheck.size()>0) {
				p.setAccNumber(acccheck.get(0).getAccNumber());
				p.setId(acccheck.get(0).getId());
				String existbal = acccheck.get(0).getAccBalance();
				Double existingbal = Double.parseDouble(existbal);
				Double totBalance = existingbal+transferringamt;
				String tot = String.valueOf(totBalance);
				p.setAccBalance(tot);
				accbalanceRepo.save(p);
				p.setId(existingamt.get().getId());
				p.setAccNumber(existingamt.get().getAccNumber());
				Double diff = balanceamt - transferringamt;
				String diffupdate = String.valueOf(diff);
				p.setAccBalance(diffupdate);
				PassBook pass = new PassBook();
				pass.setBalanceAmt(diffupdate);
				pass.setCredit("0");
				pass.setDebit(amt);
				LocalDateTime myDateObj = LocalDateTime.now();
			    DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
			    String formattedDate = myDateObj.format(myFormatObj);
				pass.setTime(formattedDate);
				pass.setAccNo(accno);
				passbookRepo.save(pass);
				accbalanceRepo.save(p);
			}
			else {
				stat = 1;
			}
		}
		else {
			stat = 1;
		}
		return stat;
	}

	public Optional<PassBook> viewPassBook(int id, String accno, String name) {
		return passbookRepo.findById(id);
	}

	public Object getIdAccnoName(String custlogMail) {
		List<AccountHolderCustomer> getIdAccnoName = accholderRepo.findByCustEmail(custlogMail);
		String custacc = getIdAccnoName.get(0).getCustAccNo();
		return passbookRepo.findByAccNo(custacc);
	}
	
}
