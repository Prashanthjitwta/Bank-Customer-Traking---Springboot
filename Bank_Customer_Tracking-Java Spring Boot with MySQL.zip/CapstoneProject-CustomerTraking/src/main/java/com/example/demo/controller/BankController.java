package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.example.demo.entity.RequestCustomer;
import com.example.demo.service.CustomerService;

@RestController
public class BankController {
	
	@Autowired
	private CustomerService CustServ; 
	
	String custlogMail;
	@GetMapping("/home")
	public ModelAndView home() {
		ModelAndView modelandview = new ModelAndView();
		modelandview.setViewName("BankHome");
		return modelandview;
	}
	
	@GetMapping("/contact-us")
	public ModelAndView contactus() {
		ModelAndView modelandview = new ModelAndView();
		modelandview.setViewName("contactus");
		return modelandview;
	}
	
	@GetMapping("/new-account-request")
	public ModelAndView newAcc() {
		ModelAndView modelandview = new ModelAndView();
		modelandview.setViewName("OpenAcc");
		return modelandview;
	}
	
	@PostMapping("/new-account-request")
	public ModelAndView tempCustmer(Model model,RequestCustomer newcustomer,@RequestParam("custAadhar") String aadharno,
			@RequestParam("custAccType") String acctype) {
		ModelAndView modelandview = new ModelAndView();
		model.addAttribute("newcustomer",CustServ.saveNewRequest(newcustomer,aadharno,acctype));
		modelandview.setViewName("OpenAcc");
		return modelandview;
	}
	
	@PostMapping("/login")
	public RedirectView loginRoles(@RequestParam("loginrdobtn") int role,@RequestParam("mail") String logMail,
			@RequestParam("pass") String logPass) {
		if(role == 1) {
			int logStat = CustServ.logValidation(role,logMail,logPass);
			if(logStat == 1) {
				return new RedirectView("/Bank_Staff");
			}
			if(logStat == 0) {
				return new RedirectView("/home");
			}
		}
		if(role == 2) {
			int logStat = CustServ.logValidation(role,logMail,logPass);
			if(logStat == 1) {
				custlogMail = logMail;
				return new RedirectView("/Customer");
			}
			if(logStat == 0) {
				return new RedirectView("/home");
			}
			
		}
		return new RedirectView("/home");
	}

	
	@GetMapping("/Bank_Staff")
	public ModelAndView bankStaff() {
		ModelAndView modelandview = new ModelAndView();
		modelandview.setViewName("BankStaff");
		return modelandview;
	}

	
	@GetMapping("/ViewAllCustomers")
	public ModelAndView viewAllCustomers(Model model) {
		ModelAndView modelandview = new ModelAndView();
		model.addAttribute("customers",CustServ.getAllCustomers());
		modelandview.setViewName("ViewAllCustomers");
		return modelandview;
	} 
	
	@GetMapping("/SearchByAccountNumber")
	public ModelAndView searchByAccountNumber() {
		ModelAndView modelandview = new ModelAndView();
		modelandview.setViewName("SearchByAccNo");
		return modelandview;
	} 
	
	@GetMapping("/AccountNumberSearch")
	public ModelAndView AccountNumberSearch(@RequestParam String accno,Model model) {
		ModelAndView modelandview = new ModelAndView();
		model.addAttribute("customerbyid",CustServ.getCustomerById(accno));
		modelandview.setViewName("SearchByAccNo");
		return modelandview;
	} 
	
	@GetMapping("/NewAccountAccess")
	public ModelAndView newAccountAccess(Model model) {
		ModelAndView modelandview = new ModelAndView();
		model.addAttribute("customerrequest",CustServ.showAllNewRequest());
		modelandview.setViewName("NewAccReq");
		return modelandview;
	} 
	
	@GetMapping("/AccountBalance")
	public ModelAndView accountBalance() {	
			ModelAndView modelandview = new ModelAndView();
			modelandview.setViewName("CheckAccBalance");
			return modelandview;
	} 
	
	@GetMapping("/CheckBalance")
	public ModelAndView accountBalance(@RequestParam String accNumber,Model model) {	
			ModelAndView modelandview = new ModelAndView();
			model.addAttribute("customerbybalance",CustServ.checkCustomerBalance(accNumber));
			modelandview.setViewName("CheckAccBalance");
			return modelandview;
	} 
	
	@GetMapping("approve_new_acc")
	public RedirectView accountApprove(@RequestParam int id,Model model) {   
		CustServ.provideAccess(id);
		return new RedirectView("/NewAccountAccess");
	}
	
	@GetMapping("cancel_request")
	public RedirectView accountRequestCancel(@RequestParam int id,Model model) {   
		CustServ.denyAccess(id);
		return new RedirectView("/NewAccountAccess");
	}
	
	@GetMapping("/Customer")
	public ModelAndView customerOperation() {
		ModelAndView modelandview = new ModelAndView();
		modelandview.setViewName("Customer");
		return modelandview;
	}
	
	@GetMapping("/editMyDetails")
	public ModelAndView editMyDetails(Model model) {
		ModelAndView modelandview = new ModelAndView();
		model.addAttribute("editcustomer",CustServ.editCustomerDetails(custlogMail));
		modelandview.setViewName("EditMyDetails");  
		return modelandview;
	}
	
	@PostMapping("/edit-account-details")
	public ModelAndView editaccdetails(Model model,@RequestParam("custEmail") String email,@RequestParam("custPhone") String phone,
			@RequestParam("id") int id, @RequestParam("custPass") String pass) {
		ModelAndView modelandview = new ModelAndView();
		model.addAttribute("savecustomer",CustServ.saveEditRequest(email,phone,pass,id));
		modelandview.setViewName("BankHome");
		return modelandview;
	}
	
	@GetMapping("/addMoney")
	public ModelAndView addMoney(Model model) {
		ModelAndView modelandview = new ModelAndView();
		model.addAttribute("editcustomer",CustServ.editCustomerDetails(custlogMail));
		modelandview.setViewName("addMoney");  
		return modelandview;
	}
	
	@PostMapping("/addbalance")
	public RedirectView addbalance(Model model,@RequestParam("addbalance") String amt, @RequestParam("id") int id,@RequestParam("accno") String accno) throws InterruptedException {
		ModelAndView modelandview = new ModelAndView();
		model.addAttribute("addAmount",CustServ.addAmt(amt,id,accno));
		return new RedirectView("addMoney");
	}
	
	@GetMapping("/accountTransfer")
	public ModelAndView transferMoney(Model model) {
		ModelAndView modelandview = new ModelAndView();
		model.addAttribute("editcustomer",CustServ.editCustomerDetails(custlogMail));
		modelandview.setViewName("transferMoney");  
		return modelandview;
	}
	
	@PostMapping("/transferamt")
	public RedirectView addbalance(Model model,@RequestParam("id") int id, @RequestParam("accno") String accno,@RequestParam("addamt") String amt,@RequestParam("toacc") String toacc) throws InterruptedException {
		ModelAndView modelandview = new ModelAndView();
		int status = CustServ.addAmt(amt,id,accno,toacc);
		if(status == 0) {
			return new RedirectView("/accountTransfer");
		}
		if(status == 1) {
			modelandview.setViewName("Exception");
		}
		return new RedirectView("/Exception");
	}
	@GetMapping("/Exception")
	public ModelAndView Exception(Model model) {
		ModelAndView modelandview = new ModelAndView();
		modelandview.setViewName("Exception");  
		return modelandview;
	}
	
	@GetMapping("/passBook")
	public ModelAndView passBook(Model model) {
		ModelAndView modelandview = new ModelAndView();
		model.addAttribute("passBook",CustServ.getIdAccnoName(custlogMail));
		modelandview.setViewName("passBook");  
		return modelandview;
	}
	
	@GetMapping("/viewpassBook")
	public ModelAndView viewpassBook(Model model,@RequestParam("id") int id, @RequestParam("accno") String accno,@RequestParam("name") String name) {
		ModelAndView modelandview = new ModelAndView();
		model.addAttribute("balance",CustServ.editCustomerDetails(custlogMail));
		model.addAttribute("passbook",CustServ.viewPassBook(id,accno,name));
		modelandview.setViewName("passBook");  
		return modelandview;
	}
}