package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.RequestCustomer;

@Repository
public interface AccRequestRepository extends JpaRepository<RequestCustomer,Integer>{

	List<RequestCustomer> findByCustAadharAndCustAccType(String aadharno, String acctype);

}
